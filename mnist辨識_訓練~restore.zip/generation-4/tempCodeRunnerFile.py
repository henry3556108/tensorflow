kpt.model_checkpoint_path)
                                # global_step = ckpt.model_checkpoint_path.split('-')[-1]
                                # accuracy_score = sess.run(accuracy,feed_dict = v_feed)
                                # print('afte